#!/usr/bin/env python

import sys
import rospy
from capstone_msgs.srv import *

def add_two_ints_client(array1):
    result =[]
    rospy.wait_for_service('add_two_ints')
    try:
        add_two_ints = rospy.ServiceProxy('add_two_ints', goalPoint)
        kk = goalPoint()
        kk.goal_point = array1
        result = add_two_ints(kk.goal_point)
        print "result:", result
        return result
    except rospy.ServiceException, e:
        print "Service call failed: %s"%e

def usage():
    return "%s [x y]"%sys.argv[0]

if __name__ == "__main__":
    if len(sys.argv) == 3:
        x = float(sys.argv[1])
        y = float(sys.argv[2])
        array1 = [x,y]
        print array1
        add_two_ints_client(array1)
    else:
        print usage()
        sys.exit(1)
    print "Requesting %s+%s"%(x, y)