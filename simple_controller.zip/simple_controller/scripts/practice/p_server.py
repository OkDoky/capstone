#!/usr/bin/env python

from capstone_msgs.srv import goalPoint
import rospy

def add_two_points(req):
    print "point x : %s, point y : %s"%(req.goal_point_x, req.goal_point_y)
    return goalPointResponse(req.goal_point_x, req.goal_point_y)

def add_two_ints_server():
    rospy.init_node('add_two_ints_server')
    s = rospy.Service('add_goal_point', goalPoint, add_two_points)
    print "Ready to add two ints."
    rospy.spin()

if __name__ == "__main__":
    add_two_ints_server()