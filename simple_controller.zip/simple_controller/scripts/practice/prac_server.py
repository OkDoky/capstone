#!/usr/bin/env python

from capstone_msgs.srv import *
import rospy

def handle_add_two_ints(req):
	res = goalPointResponse()
	res.send_point = req.goal_point
	return res

def add_two_ints_server():
	rospy.init_node('add_two_ints_server')
	rospy.Service('add_two_ints', goalPoint, handle_add_two_ints)
	print "Ready to add two ints."
	rospy.spin()


if __name__ == "__main__":
	add_two_ints_server()